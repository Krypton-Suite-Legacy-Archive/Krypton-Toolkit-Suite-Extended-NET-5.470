﻿namespace ExtendedControls.ExtendedToolkit.Controls.AdvancedKryptonOutlookGrid.Controls
{
    partial class AdvancedDataGridViewSearchToolBar
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnClose = new System.Windows.Forms.ToolStripButton();
            lblSearch = new System.Windows.Forms.ToolStripLabel();
            cmbColumns = new System.Windows.Forms.ToolStripComboBox();
            txtSearch = new System.Windows.Forms.ToolStripTextBox();
        }

        #endregion

        private System.Windows.Forms.ToolStripButton btnClose;
        private System.Windows.Forms.ToolStripLabel lblSearch;
        private System.Windows.Forms.ToolStripComboBox cmbColumns;
        private System.Windows.Forms.ToolStripTextBox txtSearch;
        private System.Windows.Forms.ToolStripButton btnFromBegin;
        private System.Windows.Forms.ToolStripButton btnCaseSensitive;
        private System.Windows.Forms.ToolStripButton btnSearch;
        private System.Windows.Forms.ToolStripButton btnWholeWord;
        private System.Windows.Forms.ToolStripSeparator sepSearch;
    }
}
