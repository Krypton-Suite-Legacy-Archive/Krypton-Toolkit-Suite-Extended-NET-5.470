﻿using System.ComponentModel;
using System.Windows.Forms;

namespace ExtendedControls.ExtendedToolkit.Controls.AdvancedKryptonOutlookGrid.Controls
{
    [DesignerCategory("")]
    public partial class AdvancedDataGridViewSearchToolBar : ToolStrip
    {
        public AdvancedDataGridViewSearchToolBar()
        {
            InitializeComponent();
        }
    }
}
